package sample;

import sample.Pessoal;

public class Professor {
    private String salario;
    private Pessoal pessoal;

    public Professor(String salario, Pessoal pessoal) {
        this.salario = salario;
        this.pessoal = pessoal;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    public Pessoal getPessoal() {
        return pessoal;
    }

    public void setPessoal(Pessoal pessoal) {
        this.pessoal = pessoal;
    }

    @Override
    public String toString() {
        return  "salario: " + salario +
                ", pessoal: " + pessoal;
    }
}
