package sample.model;


import sample.Aluno;
import sample.Endereco;
import sample.Pessoal;
import sample.Professor;

public class Main{

    public static void main(String[] args) {

        Aluno aluno1 = new Aluno("1234", "7", pessoal1);
        Pessoal pessoal1 = new Pessoal("Horácio Romeu", "9999-9999", "hromeu@hotmail.com");
        Pessoal pessoal2 = new Pessoal("paulo batinelas", "6666-6666", "paulobattistela@senai.br");
        Endereco endereco1 = new Endereco("sla", "floripa", "o q é uf?", "123134", "brasil sil sil");
        Professor professor1 = new Professor("2 conto", pessoal2);

        System.out.println(endereco1);
        System.out.println(aluno1);
        System.out.println(professor1);


    }
}
