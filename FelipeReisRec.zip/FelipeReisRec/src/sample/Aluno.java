package sample;

public class Aluno {
    private String matricula;
    private String media;
    private Pessoal pessoal;

    public Aluno(String matricula, int media, Pessoal pessoal) {
        this.matricula = matricula;
        this.media = media;
        this.pessoal = pessoal;
    }


    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getMedia() {
        return media;
    }

    public void setMedia(int media) {
        this.media = media;
    }

    public Pessoal getPessoal() {
        return pessoal;
    }

    public void setPessoal(Pessoal pessoal) {
        this.pessoal = pessoal;
    }

    @Override
    public String toString() {
        return  "matricula: " + matricula +
                ", media: " + media +
                ", pessoal: " + pessoal;
    }
}
